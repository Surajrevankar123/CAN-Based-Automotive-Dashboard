#include <xc.h>
#include "can.h"
#include "uart.h"
#include "clcd.h"
#include "timer.h"
#include "isr.h"
#include "msg_id.h"

extern unsigned int flag = 0; 
//extern unsigned  int count =0;// Used to indicate left/right/off state for indicators

void main(void) 
{
    init_clcd();       // Initialize CLCD
    init_can();        // Initialize CAN communication
    init_uart();       // Initialize UART 
    init_timer0();
    TRISB=TRISB|0x80;
   
    TRISB0 = 0;
    TRISB1 = 0;
      
    TRISB6 = 0;
    TRISB7 = 0;// Initialize timer 
    PORTB=0x00;
    
    unsigned int recv_speed_msg_id = 0, recv_speed_length = 0;
    unsigned char recv_speed_data[5];  // Buffer to store received CAN data
    while(1)
    {
       // RB0 = 1;
        clcd_print("SP  GR  RPM  ID", LINE1(0));  
        
        // Receive CAN message (Message ID, Data Array, and Length)
        can_receive(&recv_speed_msg_id, recv_speed_data, &recv_speed_length);
      
        // ----- Display SPEED on CLCD -----
        if(SPEED_MSG_ID == recv_speed_msg_id)
        {
            recv_speed_data[2] = '\0';                 // Null-terminate the string
            clcd_print(recv_speed_data, LINE2(0));     // Print speed value at position 0
        }

        // ----- Display GEAR on CLCD -----
        else if(GEAR_MSG_ID == recv_speed_msg_id)
        {
            recv_speed_data[2] = '\0';                 // Null-terminate the string
            clcd_print(recv_speed_data, LINE2(4));     // Print gear value at position 4
        }

        // ----- Display RPM on CLCD -----
        else if(RPM_MSG_ID == recv_speed_msg_id)
        {
            recv_speed_data[recv_speed_length] = '\0'; // Null-terminate based on received length
            clcd_print(recv_speed_data, LINE2(7));     // Print RPM value at position 7
        }

        // ----- Display INDICATOR Status on CLCD -----
        else if(INDICATOR_MSG_ID == recv_speed_msg_id)
        {
            
            if(recv_speed_data[0] == '1')              // Indicator LEFT ON
            {
                RB0= 1;
                flag = 1;
                  //     count =0;
                clcd_print("<-", LINE2(13));           // Show left arrow
            }
            else if(recv_speed_data[0] == '2')         // Indicator RIGHT ON
            {
                flag = 2;
                clcd_print("->", LINE2(13));           // Show right arrow
            }
            else if(recv_speed_data[0] == '0')         // Indicator OFF
            {
                flag = 0;
                clcd_print("OF", LINE2(13));           // Show OFF text
            }
        }
    }
    return;
}
