/*
 * File:   main.h
 * Author: LENOVO
 *
 * Created on 28 December, 2025, 7:26 PM
 */


#include <xc.h>

void main(void) {
    return;
}
